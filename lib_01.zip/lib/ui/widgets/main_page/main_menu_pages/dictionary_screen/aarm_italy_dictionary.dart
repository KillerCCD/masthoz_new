import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:google_fonts/google_fonts.dart';
import 'package:mashtoz_flutter/ui/widgets/helper_widgets/actions_widgets.dart';
import 'package:tab_indicator_styler/tab_indicator_styler.dart';
import '/config/palette.dart';

class DictionaryArmItl extends StatefulWidget {
  const DictionaryArmItl({Key? key}) : super(key: key);

  @override
  _DictionaryArmItlState createState() => _DictionaryArmItlState();
}

class _DictionaryArmItlState extends State<DictionaryArmItl>
    with SingleTickerProviderStateMixin {
  late TabController _controller;

  @override
  void initState() {
    _controller = TabController(length: 2, vsync: this);

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(slivers: [
          SliverAppBar(
            title: ActionsHelper(
              //botomPadding: 55,
              text: 'Հայերեն-իտալերեն',
              fontFamily: 'Grapalat',
              rightPadding: 10.0,
              fontSize: 20,
              laterSpacing: 1,
              fontWeight: FontWeight.bold,
              color: Palette.appBarTitleColor,
              buttonShow: true,
            ),
            expandedHeight: 73,
            backgroundColor: Palette.textLineOrBackGroundColor,
            elevation: 0,
            automaticallyImplyLeading: false,
            systemOverlayStyle: SystemUiOverlayStyle(
                statusBarColor: Color.fromRGBO(25, 4, 18, 1)),
          ),
          SliverPersistentHeader(
            pinned: true,
            floating: false,
            delegate: Delegate(),
          ),
          SliverList(
            delegate: SliverChildBuilderDelegate((context, index) {
              return Container(
                padding: EdgeInsets.all(12.0),
                height: 105,
                width: 259,
                child: Column(
                  children: [
                    ListTile(
                      title: Container(
                        child: Text(
                          'Բախ Յոհանն Սեբաստիան (1685-1750) - ՀԱՐՈՒԹՅԱՆ ՕՐԱՏՈՐԻՈՒՄ',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: Color.fromRGBO(84, 112, 126, 1),
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                      onTap: () {
                        print("$index");
                      },
                      leading: Text('$index'),
                    ),
                  ],
                ),
              );
            }, childCount: 10),
          ),
        ]),
      ),
    );
  }
}

class ArmenianItalian extends StatelessWidget {
  const ArmenianItalian({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Scaffold(
        body: GridView.count(
          mainAxisSpacing: 30,
          crossAxisCount: 7,
          physics: NeverScrollableScrollPhysics(),
          children: List.generate(wordsArm.length, (index) {
            return Center(
              child: InkWell(
                onTap: () {
                  print('hi');
                },
                child: SizedBox(
                  height: 20,
                  width: 17,
                  child: Text(
                    '${wordsArm[index]}',
                    style: const TextStyle(
                        fontFamily: 'ArshaluyseArtU',
                        fontSize: 20,
                        fontStyle: FontStyle.normal,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            );
          }),
        ),
      ),
    );
  }
}

List<String> wordsArm = [
  'ա',
  "բ",
  "գ",
  "դ",
  "ե",
  "զ",
  "է",
  "ը",
  "թ",
  "ժ",
  "ի",
  "լ",
  "խ",
  "ծ",
  "կ",
  "հ",
  "ձ",
  "ղ",
  "ճ",
  "մ",
  "յ",
  "ն",
  "շ",
  "ո",
  "չ",
  "պ",
  "ջ",
  "ռ",
  "ս",
  "վ",
  "տ",
  "ր",
  "ց",
  "ու",
  "փ",
  "ք",
  "ԵՎ",
  "Օ",
  "Ֆ"
];
List<String> wordsIt = [
  'A',
  'B',
  'C',
  'D',
  'E',
  'F',
  'G',
  'H',
  'I',
  'J',
  'K',
  'L',
  'M',
  'N',
  'O',
  'P',
  'Q',
  'R',
  'S',
  'T',
  'U',
  '',
  'V',
  'W',
  'X',
  'Y',
  'Z'
];

class Delegate extends SliverPersistentHeaderDelegate {
  @override
  Widget build(
      BuildContext context, double shrinkOffset, bool overlapsContent) {
    return DefaultTabController(
        length: wordsArm.length,
        child: Scaffold(
            body: Container(
                width: double.infinity,
                child: Row(
                  children: [
                    Expanded(
                      child: Material(
                        child: TabBar(
                            indicatorWeight: 2,
                            unselectedLabelColor:
                                const Color.fromRGBO(122, 108, 115, 1),
                            labelColor: const Color.fromRGBO(251, 196, 102, 1),
                            indicatorColor: Colors.amber,
                            indicator: MaterialIndicator(
                                color: Colors.amber,
                                height: 2,
                                topLeftRadius: 0,
                                topRightRadius: 0,
                                bottomLeftRadius: 5,
                                bottomRightRadius: 5,
                                tabPosition: TabPosition.top,
                                paintingStyle: PaintingStyle.fill),
                            //  controller: _controller,
                            isScrollable: true,
                            labelPadding:
                                const EdgeInsets.symmetric(horizontal: 15),
                            tabs: wordsArm
                                .map((tabName) => Tab(
                                      child: Text(
                                        tabName,
                                        style: const TextStyle(
                                            fontFamily: 'ArshaluyseArtU',
                                            fontSize: 23,
                                            fontStyle: FontStyle.normal,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ))
                                .toList()),
                      ),
                    ),
                  ],
                ))));
  }

  @override
  double get maxExtent => 60;

  @override
  double get minExtent => 60;

  @override
  bool shouldRebuild(SliverPersistentHeaderDelegate oldDelegate) => true;
}

class ItalianArmenian extends StatelessWidget {
  const ItalianArmenian({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Scaffold(
        body: GridView.count(
          mainAxisSpacing: 30,
          crossAxisCount: 7,
          physics: NeverScrollableScrollPhysics(),
          children: List.generate(wordsIt.length, (index) {
            return Center(
              child: InkWell(
                onTap: () {
                  print('hi');
                },
                child: Text(
                  '${wordsIt[index]}',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.rye(
                      fontSize: 20,
                      fontStyle: FontStyle.normal,
                      fontWeight: FontWeight.bold),
                ),
              ),
            );
          }),
        ),
      ),
    );
  }
}
