// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:flutter_svg/flutter_svg.dart';
// import 'package:mashtoz_flutter/config/palette.dart';
// //import 'package:mashtoz_flutter/domens/fake_book_data.dart';
// import 'package:mashtoz_flutter/domens/models/book.dart';
// import 'package:photo_view/photo_view.dart';
// import 'package:photo_view/photo_view_gallery.dart';

// //import '../helper_widgets/actions_widgets.dart';

// class GalleryItem extends StatefulWidget {
//   const GalleryItem({Key? key}) : super(key: key);

//   @override
//   State<GalleryItem> createState() => _GalleryItemState();
// }

// class _GalleryItemState extends State<GalleryItem> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: CustomScrollView(
//         slivers: [
//           const SliverAppBar(
//             expandedHeight: 73,
//             backgroundColor: Palette.textLineOrBackGroundColor,
//             pinned: false,
//             floating: true,
//             elevation: 0,
//             automaticallyImplyLeading: false,
//             systemOverlayStyle: SystemUiOverlayStyle(
//                 statusBarColor: Color.fromRGBO(25, 4, 18, 1)),
//             // flexibleSpace: ActionsHelper(
//             //   leftPadding: 12,
//             //   // botomPadding: 0,
//             //   // topPadding: 30,
//             //   text: 'Պատկերադարան',

//             //   fontFamily: 'Grapalat',
//             //   fontSize: 20,
//             //   laterSpacing: 1,
//             //   fontWeight: FontWeight.bold,
//             //   color: Palette.appBarTitleColor,
//             // ),
//           ),
//           SliverFillRemaining(
//             child: ListView.builder(
//                 scrollDirection: Axis.vertical,
//                 shrinkWrap: true,
//                 itemCount: 5,
//                 itemBuilder: (context, index) {
//                   return ExpansionTile(
//                     title: SizedBox(
//                       child: Text(
//                         'Հովհաննես Առաքյալ և Ավետարանիչ',
//                         textAlign: TextAlign.center,
//                       ),
//                     ),
//                     controlAffinity: ListTileControlAffinity.leading,
//                     initalIcon: SvgPicture.asset('assets/images/line24.svg'),
//                     //leading: Icon(Icons.rotate_90_degrees_ccw),
//                     children: [
//                       GridView.builder(
//                         shrinkWrap: true,
//                         scrollDirection: Axis.vertical,
//                         // itemCount: galleryItems.length,
//                         itemBuilder: (context, index) {
//                           // Gellerys gallery = galleryItems[index];

//                           return Text('data');
//                           // return Container(
//                           //   padding:
//                           //       const EdgeInsets.symmetric(horizontal: 5.0),
//                           //   child: GestureDetector(
//                           //     onTap: () {
//                           //       open(context, index);
//                           //     },
//                           //     child: Hero(
//                           //       tag: gallery.id,
//                           //       child:
//                           //           Image.asset(gallery.resource, height: 80.0),
//                           //     ),
//                           //   ),
//                           // );
//                         },
//                         gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
//                           crossAxisCount: 2,
//                           mainAxisSpacing: 20.0,
//                         ),
//                       )
//                     ],
//                   );
//                 }),
//           )
//         ],
//       ),
//     );
//   }

//   void open(BuildContext context, final int index) {
//     Navigator.push(
//       context,
//       MaterialPageRoute(
//         builder: (context) => GalleryPhotoViewWrapper(
//           //galleryItems: ,
//           backgroundDecoration: const BoxDecoration(
//             color: Colors.black,
//           ),
//           initialIndex: index,
//         ),
//       ),
//     );
//   }
// }

// class GalleryPhotoViewWrapper extends StatefulWidget {
//   GalleryPhotoViewWrapper({
//     this.loadingBuilder,
//     this.backgroundDecoration,
//     this.minScale,
//     this.maxScale,
//     this.initialIndex = 0,
//     // required this.galleryItems,
//     this.scrollDirection = Axis.horizontal,
//   }) : pageController = PageController(initialPage: initialIndex);

//   final LoadingBuilder? loadingBuilder;
//   final BoxDecoration? backgroundDecoration;
//   final dynamic minScale;
//   final dynamic maxScale;
//   final int initialIndex;
//   final PageController pageController;
//   // final List<Gellerys> galleryItems;
//   final Axis scrollDirection;

//   @override
//   State<StatefulWidget> createState() {
//     return _GalleryPhotoViewWrapperState();
//   }
// }

// class _GalleryPhotoViewWrapperState extends State<GalleryPhotoViewWrapper> {
//   late int currentIndex = widget.initialIndex;

//   void onPageChanged(int index) {
//     setState(() {
//       currentIndex = index;
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Container(
//         decoration: widget.backgroundDecoration,
//         constraints: BoxConstraints.expand(
//           height: MediaQuery.of(context).size.height,
//         ),
//         child: Stack(
//           alignment: Alignment.bottomRight,
//           children: <Widget>[
//             PhotoViewGallery.builder(
//               scrollPhysics: const BouncingScrollPhysics(),
//               builder: _buildItem,
//               itemCount: 2, //widget.galleryItems.length,
//               loadingBuilder: widget.loadingBuilder,
//               backgroundDecoration: widget.backgroundDecoration,
//               pageController: widget.pageController,
//               onPageChanged: onPageChanged,
//               scrollDirection: widget.scrollDirection,
//             ),
//             Container(
//               padding: const EdgeInsets.all(20.0),
//               child: Text(
//                 "Image ${currentIndex + 1}",
//                 style: const TextStyle(
//                   color: Colors.white,
//                   fontSize: 17.0,
//                   decoration: null,
//                 ),
//               ),
//             )
//           ],
//         ),
//       ),
//     );
//   }

//   PhotoViewGalleryPageOptions _buildItem(BuildContext context, int index) {
//     final Gellerys item = Gellerys(id: '1', resource: 'sadas');
//     return item.isSvg
//         ? PhotoViewGalleryPageOptions.customChild(
//             child: Container(
//               width: 300,
//               height: 300,
//               child: SvgPicture.asset(
//                 item.resource,
//                 height: 200.0,
//               ),
//             ),
//             childSize: const Size(300, 300),
//             initialScale: PhotoViewComputedScale.contained,
//             minScale: PhotoViewComputedScale.contained * (0.5 + index / 10),
//             maxScale: PhotoViewComputedScale.covered * 4.1,
//             heroAttributes: PhotoViewHeroAttributes(tag: item.id),
//           )
//         : PhotoViewGalleryPageOptions(
//             imageProvider: AssetImage(item.resource),
//             initialScale: PhotoViewComputedScale.contained,
//             minScale: PhotoViewComputedScale.contained * (0.5 + index / 10),
//             maxScale: PhotoViewComputedScale.covered * 4.1,
//             heroAttributes: PhotoViewHeroAttributes(tag: item.id),
//           );
//   }
// }
