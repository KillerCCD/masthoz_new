import 'package:flutter/material.dart';
import 'package:mashtoz_flutter/domens/models/content_list.dart';

class BookInheritedWidget extends InheritedWidget {
  final Content? content;
  final Widget child;
  BookInheritedWidget(this.content, {Key? key, required this.child})
      : super(key: key, child: child);

  static BookInheritedWidget? of(BuildContext context) {
    return context.dependOnInheritedWidgetOfExactType<BookInheritedWidget>();
  }

  @override
  bool updateShouldNotify(BookInheritedWidget oldWidget) {
    return true;
  }
}
