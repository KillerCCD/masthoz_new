import 'package:flutter/material.dart';

import '/config/palette.dart';
import '/domens/repository/user_data_provider.dart';

class VerifyCodeForm extends StatefulWidget {
  final String userEmail;
  VerifyCodeForm({Key? key, required this.userEmail}) : super(key: key);

  @override
  State<VerifyCodeForm> createState() => _VerifyCodeFormState(userEmail: userEmail);
}

class _VerifyCodeFormState extends State<VerifyCodeForm> {
  String userEmail;
  _VerifyCodeFormState({required this.userEmail});
  final userDataProvder = UserDataProvider();

  final formKey = GlobalKey<FormState>();
  final controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 20.0, right: 20.0),
            child: Form(
              key: formKey,
              child: Column(
                children: [
                  SizedBox(height: 40.0),
                  // TextFormField(
                  //   // controller: controller,
                  //   cursorColor: Palette.cursor,
                  //   style: TextStyle(color: Palette.textLineOrBackGroundColor),
                  //   decoration: InputDecoration(
                  //     focusedBorder: UnderlineInputBorder(
                  //         borderSide: BorderSide(
                  //             color: Palette.textLineOrBackGroundColor)),
                  //     enabledBorder: UnderlineInputBorder(
                  //         borderSide: BorderSide(
                  //             color: Palette.textLineOrBackGroundColor)),
                  //     labelText: 'էլ. փոստ',
                  //     labelStyle: TextStyle(
                  //       fontFamily: 'Grapalat',
                  //       fontSize: 14,
                  //       color: Palette.labelText,
                  //     ),
                  //     focusColor: Palette.labelText,
                  //   ),
                  //   validator: (value) {
                  //     if (value!.contains(RegExp(
                  //         r'^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$'))) {
                  //       return 'Մուտքագրված հասցեն սխալ է';
                  //     }
                  //     return null;
                  //   },
                  // ),
                  SizedBox(height: 40.0),
                  Align(
                    alignment: Alignment.centerRight,
                    child: SizedBox(
                      width: 47,
                      child: RawMaterialButton(
                        onPressed: () {
                          if (formKey.currentState!.validate()) {
                            final _email = controller.text;
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Processing Data')),
                            );
                            userDataProvder.forgotPasswordPost(_email,
                                (success) {
                              if (success == true) {
                                userDataProvder.sendCode(_email, (sucess) {
                                  if (success == true) {
                                    // Navigator.push(
                                    //   context,
                                    //   MaterialPageRoute(
                                    //       builder: (context) =>
                                    //           VerifyCodeForm()),
                                    // );
                                  }
                                });
                              }
                            });
                          }
                        },
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          // mainAxisSize: MainAxisSize.min,
                          children: const [
                            SizedBox(
                              width: 47,
                              height: 50,
                              child: Image(
                                image: AssetImage(
                                    "assets/images/login_button.png"),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
