class Category {
  final String categoryTitle;
  final int id;

  Category({required this.categoryTitle, required this.id});

  factory Category.fromJson(Map<String, dynamic> json) {
    return Category(categoryTitle: json['category_title'], id: json['id']);
  }
}
