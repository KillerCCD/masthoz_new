class AccountApiClient {
  // Future<int> getAccountInfo(
  //   String sessionId,
  // ) async {
  //   int parser(dynamic json) {
  //     final jsonMap = json as Map<String, dynamic>;
  //     final result = jsonMap['id'] as int;
  //     return result;
  //   }

  //   final result = _networkClient.get(
  //     '/account',
  //     parser,
  //     <String, dynamic>{
  //       'api_key': Configuration.apiKey,
  //       'session_id': sessionId,
  //     },
  //   );
  //   return result;
  // }
}
