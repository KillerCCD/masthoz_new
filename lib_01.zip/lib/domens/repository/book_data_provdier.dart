import 'dart:convert';

import 'package:mashtoz_flutter/domens/models/category_lsit.dart';

import '../../globals.dart';
import '../models/content_list.dart';
import 'package:http/http.dart' as http;

class BookDataProvider {
  //  List<Content> parsedContents(String responseBody) {
  //   final parsed = jsonDecode(responseBody).cast<Map<String, dynamic>>();
  //   final content = parsed['data']['content'];
  //   return content.map<Content>((json) => Content.fromJson(json)).toList();
  // }
  Future<List<Content>> getLibrarayYbooksById(int idCategory) async {
    var libraryList = <Content>[];
    try {
      var response = await http.get(
        Uri.parse(Api.libraryCategoryById(idCategory)),
        headers: <String, String>{
          'Content-Type': 'application/json',
        },
      );

      var body = json.decode(response.body);

      var success = body['success'];
      if (success == true) {
        // print('succes');
        var content = body['data']['content'];
        print('getoteorfkldfk : ${content.runtimeType}');
        Map.from(content).forEach((key, value) {
          if (key
              .toString()
              .contains(Map.from(value).values.first.toString())) {
            var data = Content.fromJson(value);
            libraryList.add(data);
            print("kEEEEEEEEEEEEEEEEEEEEEEY::${key}");
          }
        });
      } else {
        print("failed");
      }
    } catch (e) {
      print(e);
    }
    return libraryList;
  }

  Future<List<Category>> getCategoryLists() async {
    var libraryList = <Category>[];
    //   try {
    var response = await http.get(
      Uri.parse(Api.categoryListUrl),
      headers: <String, String>{
        'Content-Type': 'application/json',
      },
    );

    var body = json.decode(response.body);

    var success = body['success'];
    if (success == true) {
      var data = body['data'];

      return (data as List).map((e) => Category.fromJson(e)).toList();
      // print(newData);
      // libraryList.addAll(newData);
    } else {
      print("failed");
    }
    return libraryList;
  }


   Future<List<Category>> fetchGalleryList() async {
    var libraryList = <Category>[];
    //   try {
    var response = await http.get(
      Uri.parse(Api.categoryListUrl),
      headers: <String, String>{
        'Content-Type': 'application/json',
      },
    );

    var body = json.decode(response.body);

    var success = body['success'];
    if (success == true) {
      var data = body['data'];

      return (data as List).map((e) => Category.fromJson(e)).toList();
      // print(newData);
      // libraryList.addAll(newData);
    } else {
      print("failed");
    }
    return libraryList;
  }
}
